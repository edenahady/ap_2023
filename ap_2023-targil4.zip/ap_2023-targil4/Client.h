//
// Created by edena on 12/26/2022.
//
#include <string>
#include "command.h"

#ifndef PROJECT_CLIENT_H
#define PROJECT_CLIENT_H

#endif //PROJECT_CLIENT_H
using namespace std;
class Client
{
private:
    string ip;
    int port;
    DefaultIO* dio;
    bool exit;
public:
    int CreateClient(char *ip, int port);
    bool check_input(char buffer[]);
    Client(string ip, int port);
    bool check_ip(const string& ip_address);
    bool HandleServer(DefaultIO *dio,string input);
    static void Download(string path, string input);
};
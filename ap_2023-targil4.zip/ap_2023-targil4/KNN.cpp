//lynn molga nagar 319090965
//eden ahady 318948106
#include "distances.h"
#include "KNN.h"
#include "knnClass.h"
#include "pair.h"
#include<iostream>
#include<vector>
#include <fstream>
//#include<sstream>
#include <string>
#include <algorithm>
//#include <cstdio>
//#include <map>
//#include <cstring>


using namespace std;

KNN::KNN(string kStr1, string disStr1, string fileStr1) {
    kStr = kStr1;
    disStr = disStr1;
    fileStr = fileStr1;
}

string KNN::getK(){
    return kStr;
}
string KNN::getDis() {
    return disStr;
}
void KNN::setDis(string dis){
    this->disStr = dis;
}
string KNN::setFile(string file){
    this->fileStr = file;
}
void KNN::setK(string k){
    this->kStr = k;
}

bool KNN::checkK(string kStr) //check k input is a possitive int
{
    for (int i=0; i<kStr.size(); i++)
    {
        if (kStr[i] == ' ' && (i != 0 && i != kStr.size() - 1)) //checks if theres a blank space
        {
            return false;
        }
        for (int j = 0; j< kStr.size(); j++)
        {
            if (!isdigit(kStr[i])) //checks all characters are numbers
            {
                return false;
            }

        }
    }
    return true;
}

bool KNN::checkDis(string disStr) //checks that the name of distance is from list
{
    if(disStr == "AUC" || disStr == "MAN" || disStr == "CHB" || disStr == "CAN" || disStr == "MIN")
    {
        return true;
    }
    return false;
}

vector< vector<string> > KNN::checkFile (string fileStr) { //checks that the file exists on computer
    vector<vector<string>> content;
    vector<string> row;
    string line, word;
    ifstream infile(fileStr);
    if (infile) {
        while (getline(infile, line)) {
            row.clear();
            stringstream str(line);
            while (getline(str, word, ',')) {

                row.push_back(word); //inserts into inner vector

            }
            content.push_back(row); //inserts into outer vector
        }
        infile.close();
        return content;
    }
    else
    {
        cout<<"Could not open the file\n";
    }
    infile.close();
    vector<vector<string>> empty;
    return empty;
}

string KNN::Check_Input(string kStr, string disStr, string fileStr, string vecStr) //checks input is valid
{
    KNN obj = KNN(kStr, disStr, fileStr);
    int numK;
    if (obj.checkK(kStr))
    {
        //if k is a number then cast to int
        istringstream(kStr) >>numK;
    }
    else{
        return "invalid input";
    }
    if(!obj.checkDis(disStr))
    {
        return "invalid input";
    }
    vector<vector<string>> lines = obj.checkFile( fileStr); //checks if file is valid
    if(numK > lines.size()) //checks if k is bigger than amount of samples
    {
        return "invalid input";
    }
    string num;
    if (lines.empty()) //checks if file is empty
    {
        return "invalid input";
    }
    vector<string> v1;
    for (int i = 0; i < vecStr.size(); i++) {
        if (vecStr[i] == ' ' &&
            (i != 0 && i != vecStr.size() - 1)) //check that there are no blank spaces before or after vector input
        {
            continue;
        }
        while (vecStr[i] != ' ' && i < vecStr.size()) //if not space
        {
            num.push_back(vecStr[i]);
            i++;
        }
        for (int j = 0; j < num.size(); j++) {
            if (!isdigit(num[j]) && num[j] != '.' && num[j] != 'e') //check that it is a number and not a letter or symbol
            {
                return "invalid input";
            }

        }
        v1.push_back(num);
        num = "";

    }
    for (int i = 0; i < lines.size(); i++) //checks that the sizes of the vectors in the file are the same
    {
        if (lines[1].size() != lines[i].size()) {
            return "invalid input";
        }
    }
    if (v1.size() != lines[1].size() - 1) //checks that the size of users vector is the same as file
    {
        return "invalid input";
    }
    vector<double> doublev1;
    doublev1.reserve(v1.size());
    transform(v1.begin(), v1.end(), back_inserter(doublev1),
              [](string const &val) { return stod(val); }); //casts string vector into double
    knnClass findK = knnClass(lines, doublev1, disStr, numK); //knnclass object
    vector<Pair> pairs = findK.calcDist(); //claculates the distance using the distance given
    pairs = findK.sortvec(pairs); //sorts the vector of pairs
    string s = findK.classification(pairs); //finds classification
    return s;
}
string KNN:: VectorClassification(vector<string> vecStr, vector<vector<string>> trainVec, int kTemp)
{
    string num;
    vector<string> v1;
    if(kTemp > trainVec.size()) //checks if k is bigger than amount of samples
    {
        return "invalid input";
    }
    for (int i = 0; i < vecStr.size(); i++) {
        for (int j = 0; j < vecStr[i].size(); j++) {
            if (!isdigit(vecStr[i][j]) && vecStr[i][j] != '.' && vecStr[i][j] != 'E' && vecStr[i][j]!= '\r'
                && vecStr[i][j] != '-') //check that it is a number and not a letter or symbol
            {
                return "invalid input";
            }

        }

    }
    vector<double> doublev1;
    doublev1.reserve(vecStr.size());
    transform(vecStr.begin(), vecStr.end(), back_inserter(doublev1),
              [](string const &val) { return stod(val); }); //casts string vector into double
    int k = stoi(kStr);
    knnClass findK = knnClass(trainVec, doublev1, disStr, k); //knnclass object
    vector<Pair> pairs = findK.calcDist(); //claculates the distance using the distance given
    pairs = findK.sortvec(pairs); //sorts the vector of pairs
    string s = findK.classification(pairs); //finds classification
    return s;
}
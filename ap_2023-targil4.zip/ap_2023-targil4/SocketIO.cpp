//
// Created by valle on 20/01/2023.
//

#include "SocketIO.h"
#include <iostream>
#include <sys/socket.h>
#include <cstdio>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <algorithm>


string SocketIO::read() {
    string input;
    int read_bytes, expected_data_len;
    do {
        char buffer[4096];
        memset(buffer, 0, sizeof(buffer));
        expected_data_len = sizeof(buffer);
        //reciving the data
        read_bytes = recv(client_sock, buffer, expected_data_len, 0);
        //concates the inputs
        input = input + buffer;
    } while (expected_data_len == input.length());
    if (read_bytes == 0) {
        perror("connection is closed");
        return "";
    } else if (read_bytes < 0) {
        perror("error receiving from client");
        return "-1";
    }
    return input;
}

void SocketIO::write(string response) {
    char output[4096];
    memset(output, 0, sizeof(output)); //resets to 0
    strcpy(output, response.c_str());
    //sends the data 
    int sent_bytes = send(this->client_sock, output, sizeof(output), 0);
}


//
// Created by edena on 1/15/2023.
//

#include "CLI.h"
#include <string>

CLI::CLI(DefaultIO *dio){
    this->dio = dio;
    DataCmd data;
    //creating all the commands
    this->dataCmd = data;
    this->uploadCom = new UploadCommand(dio, &dataCmd);
    this->settingCom = new AlgoSettingCommand(dio, &dataCmd);
    this->classCom = new ClassifyDataCommand(dio, &dataCmd);
    this->resultsCom = new ShowResultsCommand(dio, &dataCmd);
    this->downloadCom = new DownloadsResultsCommand(dio, &dataCmd);
    this->exitCommand = new ExitCommand(dio, &dataCmd);
    this->allCommands.push_back(uploadCom);
    this->allCommands.push_back(settingCom);
    this->allCommands.push_back(classCom);
    this->allCommands.push_back(resultsCom);
    this->allCommands.push_back(downloadCom);
    this->allCommands.push_back(exitCommand);
}

void CLI::start() {
    int choice = 0;
    //run until we get 8
    while (choice != 8) {
        //printing the menu
        dio->write("Welcome to the KNN Classifier Server. Please choose an option:\n");
        for (int i = 0; i < allCommands.size(); ++i) {
            dio->write(allCommands[i]->getDescription());
        }
        string pick = dio->read(); //getting option from user

        if (!all_of(pick.begin(), pick.end(), ::isdigit) || pick == "")
        {
            continue;
        }

        choice = stoi(pick);
        //check if the choise is valid
        if (choice < 1 || choice > 6) {
            continue;
        }
        allCommands.at(choice - 1)->execute();
    }
}


CLI::~CLI() {
    //deleting all the commands
    delete uploadCom;
    delete settingCom;
    delete classCom;
    delete resultsCom;
    delete downloadCom;
    delete exitCommand;
    //delete myData;
}


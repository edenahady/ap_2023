//
// Created by valle on 20/01/2023.
//

#ifndef AP_2023_SOCKETIO_H
#define AP_2023_SOCKETIO_H

#include "command.h"

class SocketIO : public DefaultIO {
    int client_sock;
public:
    SocketIO(int client_sock) {
        this->client_sock = client_sock;
    }

    string read();

    void write(string response);
};


#endif //AP_2023_SOCKETIO_H

# targil 4
### Instructions on how to run and compile exercise 4:
Run the following commands on the server:
1. git init
2. git clone -b targil4 https://github.com/lynnmolga/ap_2023.git
3. cd ap_2023 (in order to enter the folder of the repository)
4. make

<ins>In server terminal:</ins>

5. ./server.out + "Your arguments" (port number)
6. make clean (to clean all cache)

<ins>In client terminal:</ins>

5. ./server.out + "Your arguments" (IP number and port number)
6. use menu however you wish
7. make clean (to clean all cache)

### Our code:
Our code has two main functions that communicate with each other via socket and port. 

The main function in the Server class recieves a port as an argument from the user and with this port binds to the client and opens a new thread.

The main function in the Client class recieves an IP address and a port number as arguments from the user and binds through this port to the server. After the connection is established the client prints the menu it recieves from the server for the users use. The client checks if the given input it valid (a number between 1 and 5 or 8) and sends it to the server, if it is not the client prints the menu again.

The server recieves the chosen option, calls the command header which then executes the proper function. If an invalid inout is recieved in these functions an error message will apear and we will return to menu again.

#### <ins>notes:</ins>
*After uploading the files, once you choose option 3 it may take some time to classify all the vectors if the file is large, please be patient.

*If you wish to open one of the three files we have in our datasets folder please enter in the file path: /u/students/"Your username"/ap_2023/datasets/"dataset type"/"dataset"_classified.csv

*Our code accepts a k in any size and only after choosing option 3 (classify data) it will check if the k is in the right size according to the train file.

*If the input file is anything other than a series of numbers with the classification after (e.g 1 2 3 Class) such as letters or symbols the function will stop and send an error message, same as for k.

*In the case where the size of the vectors in the file are not the same the function will stop and send an error message.

*If the file is not found or cant be opened then you will recieve the message "invalid input" in the clients terminal.

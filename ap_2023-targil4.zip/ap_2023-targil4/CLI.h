//
// Created by edena on 1/15/2023.
//

#ifndef AP_2023_CLI_H
#define AP_2023_CLI_H

#include "stdlib.h"
#include <vector>
#include <string.h>
#include "command.h"

using namespace std;

class CLI {
    DefaultIO *dio;
    DataCmd dataCmd;
    //add all kinds of commands.
    AlgoSettingCommand *settingCom;
    ClassifyDataCommand *classCom;
    DownloadsResultsCommand *downloadCom;
    ExitCommand *exitCommand;
    ShowResultsCommand *resultsCom;
    UploadCommand *uploadCom;
    vector<Command *> allCommands;
    // you can add data members
public:
    CLI(DefaultIO *dio);

    void start();

    virtual ~CLI();
};

#endif //AP_2023_CLI_H
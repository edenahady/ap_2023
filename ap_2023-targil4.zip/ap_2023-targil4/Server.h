//
// Created by edena on 12/25/2022.
//

#include "KNN.h"
#include "command.h"
#include "SocketIO.h"

#ifndef PROJECT_SERVER_H
#define PROJECT_SERVER_H

#endif //PROJECT_SERVER_H
class Server
{
private:
    int port;
    DefaultIO* dio;
//    string file;
//    string vec;
public:
    Server(int port);
    void HandleClient(SocketIO *sio);
    int CreateServer(int server_port);
    KNN Object_Maker(char buffer[], string file);
};
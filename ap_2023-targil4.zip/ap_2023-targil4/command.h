//
// Created by edena on 1/13/2023.
//

#ifndef AP_2023_COMMAND_H
#define AP_2023_COMMAND_H
#include <fstream>
#include <iostream>
#include <string.h>
#include <sstream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include "KNN.h"


using namespace std;

class DefaultIO {
protected:
    ofstream out;
    ifstream in;
public:
    virtual string read() = 0;

    virtual void write(string text) = 0;

    virtual ~DefaultIO() {}


};

class StandardIO : public DefaultIO {

public:
    StandardIO(string inputFile, string outputFile) {
        in.open(inputFile);
        out.open(outputFile);
    }

    string read() {
        string str;
        getline(cin, str);
        return str;
    }

    void write(string text) {
        cout << text;
    }


    void read(float *f) {
        in >> *f;
    }
};

class MyData{

public:
    KNN knnObj = KNN("5", "AUC", " ");
    string kData = "5";
    string disData = "AUC";
    string fileData = " ";
    string trainFile = "trainfile.csv", testFile = "tetstfile.csv";
    vector<vector<string>> trainVector;
    vector<vector<string>> testVector;
    vector<vector<string>> output;

    string getK() { //get k
        return this->knnObj.getK();
    }

    void setK(string k) { //set new k
        this->knnObj.setK(k);
        this->kData = k;
    }
    string getDis() { //get distance
        return this->knnObj.getDis();
    }
    void setDis(string dis) { //set new distance
        this->knnObj.setDis(dis);
        this->disData = dis;
    }
    void setFiles(string train, string test){ //set new files
        this->testFile = test;
        this->trainFile = train;
    }
    void setTrainFile(string train) { //set only train file
        ifstream trainPath(train);
        if (trainPath) {
            this->knnObj = KNNCreator(kData, disData, train);
            this->fileData = train;
        }
    }
    KNN KNNCreator(string newK, string newDis, string newFile) //creat new KNN object
    {
        KNN newKNN = KNN(newK, newDis, newFile);
        return newKNN;
    }
};

class DataClassifier : public MyData{
public:
    DataClassifier( MyData* data) {
        this->knnObj = data->knnObj;

    }
    bool checkVecFile(string train, string test, MyData* data)
    {
        ifstream trainPath(data->trainFile);
        //checks the file and creates vector of vectors
        vector<vector<string>> trainVector = this->knnObj.checkFile(data->trainFile);
        ifstream testPath(data->testFile);
        string testInput;
        //checks the file and creates vector of vectors
        vector<vector<string>> testVector = this->knnObj.checkFile(data->testFile);
        this->testVector = testVector;
        this->trainVector = trainVector;
        for (int i = 0; i < trainVector.size(); i++) //checks that the sizes of the vectors in the file are the same
        {
            if (trainVector[1].size() != trainVector[i].size()) {
                return false;
            }
        }
        for (int i = 0; i < testVector.size(); i++) //checks that the sizes of the vectors in the file are the same
        {
            if (testVector[1].size() != testVector[i].size()) {
                return false;
            }
        }
        if(trainVector[1].size()-1 != testVector[1].size()) //checks that the size of the train is the size of test+1
        {
            return false;
        }
        return true;
    }

    bool CreateOutput(DataClassifier classifier)
    {
        vector<vector<string>> output1;
        output1.resize(this->testVector.size());
        string classify;
        int k = stoi(this->kData);
        for(int i = 0; i < this->testVector.size(); i++) {
            for (int j = 0; j < this->testVector[i].size(); j++) {
                output1[i].push_back(this->testVector[i][j]); //push back the original vector
            }
            //classify the vector
            classify = this->knnObj.VectorClassification(this->testVector[i], this->trainVector, k);
            if(classify == "invalid input")
            {
                return false;
            }
            output1[i].push_back(classify); //push back the classification
        }
        this->output = output1;
        return (true);
    }
};

struct DataCmd{
    MyData data;
    DataClassifier classifier = new DataClassifier(&data);
    bool flagDataUpload = false;
    bool flagClassified = false;
};

class Command {
protected:
    DefaultIO *dio;
    string commandDescrip = "empty";  //
    DataCmd *dataCmd;

public:
    Command(DefaultIO *dio, DataCmd *dataCmd) :dio(dio), dataCmd(dataCmd) {}

    virtual void execute() = 0;

    string getDescription() {
        return this->commandDescrip;
    }
    bool upload(string cmd) {
        dio->write(cmd);
        string line = dio->read();
        if (line == "failed"){ //couldn't open the file in client
            return false;
        }
        int postrain = cmd.find("train"); //checks if command is for test or train files
        int postest = cmd.find("test");
        if (postrain > 0) { //if train file
            this->dataCmd->data.trainFile = "trainFile.csv";
            ofstream filePath("trainFile.csv"); // creates train file
            if (filePath) {
                while(line != "Done") {
                    filePath << line << endl; //writes into train file line by line
                    line = dio->read();
                }
                dio->write("Upload complete.\n");
            } else {
                dio->write("invalid input\n");
                return false;
            }
        } else if (postest > 0) {//if test file
            this->dataCmd->data.testFile = "testFile.csv";
            ofstream filePath("testFile.csv");// creates test file
            if (filePath) {
                while(line != "Done") {
                    filePath << line << endl; //writes into test file line by line
                    line = dio->read();
                }
                dio->write("Upload complete.\n");
            } else {
                dio->write("invalid input\n");
                return false;
            }
            filePath.close();
            return true;
        }
        return true;
    }
    virtual ~Command() {}
};

class UploadCommand : public Command {
public:
    UploadCommand(DefaultIO *dio, DataCmd *dataCmd) : Command(dio, dataCmd) {
        this->commandDescrip = "1. upload an unclassified csv data file.\n";
    }

    void execute() {
        string trainCmd = "Please upload your local train CSV file.\n";
        string testCmd = "Please upload your local test CSV file.\n";
        bool flag = upload(trainCmd); //calls upload for train
        if(!flag)
        {
            return;
        }
        bool flag2 = upload (testCmd); //calls upload for test
        if (!flag2){
            return;
        }
        this->dataCmd->flagDataUpload = true;
    }
};

class AlgoSettingCommand : public Command {
public:
    AlgoSettingCommand(DefaultIO *dio, DataCmd *dataCmd) : Command(dio, dataCmd) {
        this->commandDescrip = "2. algorithm settings\n";
    }

    void execute() {
        string dis = this->dataCmd->data.knnObj.getDis();
        string kstr = this->dataCmd->data.knnObj.getK();
        dio->write("The current KNN parameters are: K = " + kstr + ", distance metric = " + dis + "\n");
        string input = dio->read();
        if (input.empty()) //user pressed enter
        {
            return;
        }
        int count = 0;
        while (input.find(' ') != string::npos) { //didnt reach blank space
            int find = input.find(' ');
            kstr = input.substr(0, find); //splits string into k only
            input = input.substr(find + 1); //splits string into distance only
            count++; //number of spaces in string
            if (count > 1) {
                dio->write("too many argument");
                return;
            }
            bool checkK = this->dataCmd->data.knnObj.checkK(kstr); //checks if k is valid
            if (!checkK) {
                dio->write("invalid value for K\n");
                return;
            }
            bool checkDis = this->dataCmd->data.knnObj.checkDis(input);//checks if distance is valid
            if (!checkDis) {
                dio->write("invalid value for metric\n");
                return;
            }
            this->dataCmd->data.setK(kstr);
            this->dataCmd->classifier.setK(kstr);
            this->dataCmd->data.setDis(input);
            this->dataCmd->classifier.setDis(input);
            return;
        }
        int blankpos = input.find(' ');
        if (blankpos < 0){
            dio->write("missing argument\n");
            return;
        }
    }
};


class ClassifyDataCommand : public Command {
public:
    ClassifyDataCommand(DefaultIO *dio, DataCmd *dataCmd) : Command(dio, dataCmd) {
        this->commandDescrip = "3. classify data\n";
    }

    void execute() {
        if (!this->dataCmd->flagDataUpload){ //didnt upload files yet
            dio->write("please upload data\n");
            return;
        } else {
            this->dataCmd->classifier.trainFile = this->dataCmd->data.trainFile;
            this->dataCmd->classifier.testFile = this->dataCmd->data.testFile;
            this->dataCmd->classifier.setTrainFile(this->dataCmd->data.trainFile);
            //checks file and creates vector of vectors
            bool flag = this->dataCmd->classifier.checkVecFile
                    (this->dataCmd->data.trainFile, this->dataCmd->data.testFile, &this->dataCmd->data);
            if (flag) { //if file is valid
                bool classFlag = this->dataCmd->classifier.CreateOutput(this->dataCmd->classifier); //classifies vectors
                if (!classFlag) {
                    dio->write("invalid input\n");
                    return;
                }
                dio->write("classifying data complete.\n");
                this->dataCmd->flagClassified = true;
            }
            else{
                dio->write("classifying data failed\n");
            }
        }
    }

};
class ShowResultsCommand : public Command {
public:
    ShowResultsCommand(DefaultIO *dio, DataCmd *dataCmd) : Command(dio, dataCmd) {
        this->commandDescrip = "4. display results\n";
    }

    void execute() {
        if (!this->dataCmd->flagDataUpload){ //checks if files were uploaded
            dio->write("please upload data\n");
            return;
        } else if (this->dataCmd->flagDataUpload){
            if (!this->dataCmd->flagClassified){ //checks if test file was classified
                dio->write("please classify the data\n");
                return;
            }
            else {
                vector<vector<string>> results = this->dataCmd->classifier.output;
                for (int i = 0; i < results.size(); i++) {
                    //sends to server line by line
                    dio->write(to_string(i + 1) + '\t' + results[i][results[i].size() - 1] + '\n');
                }
            }
            dio->write("Done.\n");
            return;
        }
    }
};
class DownloadsResultsCommand : public Command {
public:
    DownloadsResultsCommand(DefaultIO *dio, DataCmd *dataCmd) : Command(dio, dataCmd) {
        this->commandDescrip = "5. download results\n";
    }

    void execute() {
        if (!this->dataCmd->flagDataUpload) { //checks if files were uploaded
            dio->write("please upload data\n");
            return;
        } else if (this->dataCmd->flagDataUpload){
            vector<vector<string>> results = this->dataCmd->classifier.output;
            if (!this->dataCmd->flagClassified){ //checks if test file was classified
                dio->write("please classify the data\n");
                return;
            }
            ostringstream csv_contents;
            string final_string;
            for(int i = 0; i < results.size(); i++) {
                csv_contents << to_string(i + 1) << "," << results[i][results[i].size() - 1] << endl;
                final_string = csv_contents.str();
                dio->write(final_string); //sends to server line by line
                csv_contents.str("");
            }
            dio->write("Done.");
            dio->write("please upload your local output CSV file\n");
            return;
        }
    }
};
class ExitCommand : public Command {
public:
    ExitCommand(DefaultIO *dio, DataCmd *dataCmd) : Command(dio, dataCmd) {
        this->commandDescrip = "8. exit\n";
    }
    void execute() {
    }
};
#endif //AP_2023_COMMAND_H
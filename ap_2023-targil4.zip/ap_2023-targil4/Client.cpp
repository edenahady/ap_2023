//lynn molga nagar 319090965
//eden ahady 318948106
#include "Client.h"
#include "SocketIO.h"
#include "CLI.h"
#include <iostream>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <thread>

using namespace std;
//constractor
Client::Client(string ip, int port){
    this->dio = NULL;
    this->ip = ip;
    this->port = port;
    this->exit = false;
};

void Client::Download(string path, string input) //downloads the string to local csv
{
    ofstream filePath(path);
    //we open the file
    if (filePath) {
        filePath<<input;
        filePath.close();
        return;
    } else {
        perror("invalid file\n");
    }
    return;
}


bool Client::HandleServer(DefaultIO *dio, string input) {
    string newInput;
    string response;
    string line;
    string fileString = "";
    //check if the input us empty
    if (input == ""){
        return false;
    }
    int position = input.find("Welcome"); //if its the welcome message
    if (position >= 0) {
        cout<<input;
        for (int i=0; i<6; i++){
            newInput = dio->read();
            cout<<newInput; //print menu
        }
        //getting the choise from the user
        getline(cin, input);
        if (!all_of(input.begin(), input.end(), ::isdigit) || input == "") //checks if is valid
        {
            dio->write(input);
            return false;
        }
        int choice = stoi(input);
        //check if the choise number is valid
        if (choice < 1 || choice > 8 || choice == 6 || choice ==7) {
            dio->write(input);
            return false;
        }
        dio->write(input);
        bool flag = HandleServer(dio, input);
        return flag;
    }
    //if the user picks 1
    if (input == "1") {
        for (int i = 0; i < 2; i++) { //twice for train and test files
            fileString = "";
            line = "";
            newInput = dio->read();
            cout << newInput;
            //getting the file path from the user
            getline(cin, response);
            ifstream file(response); //open file from user
            if (file) {
                while (getline(file, line)) {
                    dio->write(line); //send each line
                }
                //finish writting the file content
                dio->write("Done"); //flag
                file.close();
                newInput = dio->read(); //upload complete
                cout << newInput;
            } else {
                //we could not open the file
                cout << "invalid file\n";
                dio->write("failed");
                return false;
            }
        }
        return false;
    }
    //if we pick 5
    else if(input == "5") {
        fileString = dio->read(); //file content or please upload/classify data
        string fullInput = "";
        int posPlease = fileString.find("please"); //checks if error message
        if (posPlease >= 0){
            cout<<fileString;
            return false;
        }
            while(fileString != "Done.") { //flag from server
                //writing line by line
                fullInput = fullInput + fileString; //adds lines to one string
                fileString = dio->read();
            }
        newInput = dio->read();
        cout<<newInput;
        getline(cin, response); //gets path from user
        thread th(Download, response, fullInput); //open new thread
        this_thread::sleep_for(chrono::milliseconds(20));
        th.detach();
        return false;
    }else if (input == "4"){
        newInput = dio->read();
        cout<<newInput;
        //while we didn't finish reading the file
        while(newInput != "Done.\n"){
            newInput = dio->read(); //gets output line by line
            cout<<newInput;
        }
        return false;
    }else if (input =="8"){
        this->exit = true; //flag
        return false;
    }
    return true;
}

    int Client::CreateClient(char *ip, int port) {
        const char *ip_address = ip;
        const int port_no = port;
        int sock = socket(AF_INET, SOCK_STREAM, 0); //gets socket number
        if (sock < 0) {
            perror("error creating socket");
        }
        struct sockaddr_in sin;
        memset(&sin, 0, sizeof(sin));
        sin.sin_family = AF_INET;
        sin.sin_addr.s_addr = inet_addr(ip_address);
        sin.sin_port = htons(port_no);
        if (connect(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) { //connects to server
            perror("error connecting to server");
        }
        SocketIO *sio = new SocketIO(sock);
        this->dio = sio;
        while (true) {
            string response;
            string input = this->dio->read();
            //checking for error message/update
            int findData = input.find("data");
                int findInvalid = input.find("invalid");
                int findComplete = input.find("complete");
                int findArg = input.find("argument");
                int findFail = input.find("fail");
                int findFile = input.find("file");
                //if found
                if (findInvalid > 0 || findArg > 0 || findComplete > 0 || findData > 0 || findFail > 0 || findFile >0) {
                    cout<<input;
                    continue;
                }
            bool flag = this->HandleServer(this->dio, input);
            if (flag) {
                input = this->dio->read();
                cout<<input;
                //checking again
                findData = input.find("data");
                findInvalid = input.find("invalid");
                findComplete = input.find("complete");
                findArg = input.find("argument");
                findFail = input.find("fail");
                findFile = input.find("file");
                if (findInvalid >= 0 || findArg >= 0 || findComplete >= 0 || findData >= 0 || findFail >= 0 || findFile >= 0){
                    continue;
                }
                getline(cin, response);
                this->dio->write(response);
            }
            else if (!this->exit){ //if not option 8
                continue;
            }
            else{
                break;
            }
        }
        close(sock);
        return 0;
    }

    bool Client::check_ip(const string &ip_address) {
        vector<std::string> octets;
        // Split the IP address into octets
        string octet;
        for (char c: ip_address) {
            if (c == '.') {
                octets.push_back(octet);
                octet.clear();
            } else {
                octet += c;
            }
        }
        octets.push_back(octet);

        // Check that there are exactly four octets
        if (octets.size() != 4) {
            return false;
        }

        // Check that all octets are valid
        for (const string &octet: octets) {
            // Check that the octet is not empty
            if (octet.empty()) {
                return false;
            }

            // Check that the octet contains only digits
            if (!all_of(octet.begin(), octet.end(), ::isdigit)) {
                return false;
            }

            // Check that the octet is in the range 0-255
            int octet_int = stoi(octet);
            if (octet_int < 0 || octet_int > 255) {
                return false;
            }
        }

        return true;
    }

    int main(int argc, char *argv[]) {
        if (argc != 3) {
            exit(1);
        }
        string port_str = argv[2];
        char *ip = argv[1];
        int port = stoi(port_str);
        if (port < 1024 or port > 65535) //checks port number
        {
            cout << "port number is not valid";
            return 0;
        }
        Client cl = Client(ip, port);
        bool ip_flag = cl.check_ip(ip); //true if ip is valid, false otherwise
        if (!ip_flag) {
            cout << "ip number is not valid" << endl;
            return 0;
        }
        int rec = cl.CreateClient(ip, port);
    }

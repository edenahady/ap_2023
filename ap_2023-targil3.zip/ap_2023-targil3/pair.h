#pragma once
using namespace std;
class Pair
{
    private:
    double value;
    int index;

    public:
    Pair(double value, int index);
    double getval();
    int getindex();
};
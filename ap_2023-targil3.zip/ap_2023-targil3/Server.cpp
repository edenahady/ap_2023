
#include "Server.h"
#include "KNN.h"
#include <iostream>
#include <sys/socket.h>
#include <cstdio>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <tuple>

using namespace std;
Server::Server(int port1, string file1, string vec1){
    port = port1;
    file = file1;
    vec = vec1;
};

int flag = 0;

int Server::CreateServer(int server_port, string file, Server serv) {
    int sock = socket(AF_INET, SOCK_STREAM, 0); //gets socket number
    if (sock < 0) {
        perror("error creating socket");
    }

    //socket creation,SOCK_STREAM is a const for TCP
    struct sockaddr_in sin;//struct for address
    memset(&sin, 0, sizeof(sin));//reset the struct
    sin.sin_family = AF_INET;//address protocol type
    sin.sin_addr.s_addr = INADDR_ANY;//const for any address
    sin.sin_port = htons(server_port);//define the port
    //binding the socket with bind command and checking if bind could be done
    if (bind(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
        perror("error binding socket");
    }
    if (listen(sock, 5) < 0) {//listen to up to 5 clients at a time
        perror("error listening to a socket");
    }
    while(true) {
        struct sockaddr_in client_sin;//create a address struct for the sender information
        unsigned int addr_len = sizeof(client_sin);
        int client_sock = accept(sock, (struct sockaddr *) &client_sin,
                                 &addr_len); //accept command creates a new socket for the client that wanted to connect
        if (client_sock < 0) {//check if the creation of socket for client failed
            perror("error accepting client");
        }
        while (true) {

            char buffer[4096];//create a buffer for the client
            memset(buffer, 0, sizeof(buffer));
            char output[4096];
            memset(output, 0, sizeof(output));
            int expected_data_len = sizeof(buffer);//the maximum length of data to recieve
            int read_bytes = recv(client_sock, buffer, expected_data_len,
                                  0);//recieve a message from the clients socket into the buffer
            string input(buffer);
            if (read_bytes == 0) {
                perror("connection is closed");
                break;
            } else if (read_bytes < 0) {
                perror("error receiving from client");
            }
            else {
                if (input.empty()) {
                    strcpy(output, "invalid input");
                }
                KNN obj = serv.Object_Maker(buffer, file); //makes knn object out of input
                string newK = obj.getK();
                string newDis = obj.getDis();
                string classification = obj.Check_Input(newK, newDis, file, serv.vec); //checks input given from user
                if (flag > 0 || classification == "invalid input") {
                    strcpy(output, "invalid input");
                } else {
                    strcpy(output, classification.c_str());
                }
            }
            int sent_bytes = send(client_sock, output, sizeof(output), 0); //sends message to client
            if (sent_bytes < 0) {
                perror("error sending to client");

            }
        }
    }
    close(sock);
    return 0;
}

KNN Server::Object_Maker(char buffer[], string file) {
    //string message;
    char Vec_Arr[4096];
    string kStr;
    char disStr[4096];
    string input_buffer(buffer);
    int man = input_buffer.find("MAN"); //finds where the word MAN is located
    int auc = input_buffer.find("AUC"); //finds where the word AUC is located
    int chb = input_buffer.find("CHB"); //finds where the word CHB is located
    int can = input_buffer.find("CAN"); //finds where the word CAN is located
    int min = input_buffer.find("MIN"); //finds where the word MIN is located
    if (man >= 0) {
        strncpy(Vec_Arr, buffer, man); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + man, sizeof(buffer));
    } else if (auc >= 0) {
        strncpy(Vec_Arr, buffer, auc); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + auc, sizeof(buffer));
    } else if (chb >= 0) {
        strncpy(Vec_Arr, buffer, chb); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + chb, sizeof(buffer));
    } else if (can >= 0) {
        strncpy(Vec_Arr, buffer, can); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + can, sizeof(buffer));
    } else if (min >= 0) {
        strncpy(Vec_Arr, buffer, min); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + min, sizeof(buffer));
    } else {
        flag++; //invalid
    }
    string distance(disStr);
    string vecStr(Vec_Arr);
    string num;
    for (int i = 0; i < vecStr.size(); i++) {
        if (vecStr[i] == ' ' &&
            (i != 0 && i != vecStr.size() - 1)) //check that there are no blank spaces before or after vector input
        {
            continue;
        }
        while (vecStr[i] != ' ' && i < vecStr.size()) //if not space
        {
            num.push_back(vecStr[i]);
            i++;
        }
        for (int j = 0; j < num.size(); j++) {
            if (!isdigit(num[j]) && num[j] != '.') //check that it is a number and not a letter or symbol
            {
                flag++;
            }

        }
    }
    int count = 0;
    istringstream iss(distance);
    while (distance.find(' ') != string::npos) {
        int find = distance.find(' ');
        kStr = distance.substr(find+1); //splits string into distance and k
        distance = distance.substr(0,find); //splits string into distance and k
        count++; //number of spaces in string
    }
    if (count != 1) {
        flag++;
    }
    vec = vecStr;
    KNN obj = KNN(kStr,distance,file); //creates knn object
    return obj;
}

int main(int argc, char* argv[])
{
    if(argc != 3)
    {
        exit(1);
    }
    string port_str = argv[2];
    string file = argv[1];
    int port = stoi(port_str);
    if(port < 1024 or port > 65535) //checks port number
    {
        cout<< "port number is not valid";
        return 0;
    }
    Server serv = Server(port, file, " ");
    int rec = serv.CreateServer(port, file, serv);
}

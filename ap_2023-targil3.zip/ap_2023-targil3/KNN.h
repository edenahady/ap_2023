#pragma once
#define HEADER_KNN
#include<iostream>
#include<vector>
#include <fstream>
#include<iostream>
#include<sstream>
#include <string>
#include <algorithm>
#include <stdio.h>

using namespace std;
using std::vector;
class KNN
{
private:
    string kStr;
    string disStr;
    string fileStr;
public:
    KNN(string kStr, string disStr, string fileStr);
    string getK();
    string getDis();
    string getFile();
    bool checkK(string kStr);
    bool checkDis(string disStr);
    vector< vector<string> > checkFile (string fileStr);
    string Check_Input(string kStr, string disStr, string fileStr, string vecStr);
};
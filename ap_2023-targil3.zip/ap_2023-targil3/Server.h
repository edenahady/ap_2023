//
// Created by edena on 12/25/2022.
//

#include "KNN.h"

#ifndef PROJECT_SERVER_H
#define PROJECT_SERVER_H

#endif //PROJECT_SERVER_H
class Server
{
private:
    int port;
    string file;
    string vec;
public:
    Server(int port, string file, string vec);
    int CreateServer(int server_port, string file, Server serv);
    KNN Object_Maker(char buffer[], string file);
};

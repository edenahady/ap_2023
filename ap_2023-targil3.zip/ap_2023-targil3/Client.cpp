//lynn molga nagar 319090965
//eden ahady 318948106
#include "Client.h"
#include <iostream>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

Client::Client(string ip, int port){};

int Client::CreateClient(char *ip, int port) {
    const char *ip_address = ip;
    const int port_no = port;
    int sock = socket(AF_INET, SOCK_STREAM, 0); //gets socket number
    if (sock < 0) {
        perror("error creating socket");
    }
    struct sockaddr_in sin;
    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = inet_addr(ip_address);
    sin.sin_port = htons(port_no);
    if (connect(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) { //connects to server
        perror("error connecting to server");
    }
    while(true) {
        char data_addr[4096];
        string input;
        getline(cin , input); //gets input
        if(input == "-1") //if input is -1 close socket
        {
            break;
        }
        strcpy(data_addr, input.c_str());
        bool flag = check_input(data_addr); //checks input is valid
        if(flag == false)
        {
            cout<<"invalid input"<<endl;
            continue;
        }
        int data_len = strlen(data_addr);
        int sent_bytes = send(sock, data_addr, data_len, 0); //sends message to server
        if (sent_bytes < 0) {
            cout<< "error sending to server" << endl;
        }
        char buffer[4096];
        int expected_data_len = sizeof(buffer);
        int read_bytes = recv(sock, buffer, expected_data_len, 0); //recieves message from server
        if (read_bytes == 0) {
            cout<< "connection is closed" << endl;
            break;
        } else if (read_bytes < 0) {
            perror("error receiving to server");
        }else{
            cout << buffer<<endl;
        }
    }
    close(sock);
    return 0;
}
bool Client::check_input(char buffer[])
{
    char Vec_Arr[4096];
    string kStr;
    char disStr[4096];
    string input_buffer(buffer);
    int man = input_buffer.find("MAN"); //finds where the word MAN is located
    int auc = input_buffer.find("AUC"); //finds where the word AUC is located
    int chb = input_buffer.find("CHB"); //finds where the word CHB is located
    int can = input_buffer.find("CAN"); //finds where the word CAN is located
    int min = input_buffer.find("MIN"); //finds where the word MIN is located
    if (man >= 0) {
        strncpy(Vec_Arr, buffer, man); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + man, sizeof(buffer));
    } else if (auc >= 0) {
        strncpy(Vec_Arr, buffer, auc); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + auc, sizeof(buffer));
    } else if (chb >= 0) {
        strncpy(Vec_Arr, buffer, chb); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + chb, sizeof(buffer));
    } else if (can >= 0) {
        strncpy(Vec_Arr, buffer, can); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + can, sizeof(buffer));
    } else if (min >= 0) {
        strncpy(Vec_Arr, buffer, min); //splits string into 2 (vector and distance+K)
        strncpy(disStr, buffer + min, sizeof(buffer));
    } else {
        return false; //no distance found
    }
    string distance(disStr);
    string vecStr(Vec_Arr);
    string num;
    for (int i = 0; i < vecStr.size(); i++) {
        if (vecStr[i] == ' ' && (i != 0 && i != vecStr.size() - 1)) //check that there are no blank spaces before or after vector input
        {
            continue;
        }
        while (vecStr[i] != ' ' && i < vecStr.size()) //if not space
        {
            num.push_back(vecStr[i]);
            i++;
        }
        for (int j = 0; j < num.size(); j++) {
            if (!isdigit(num[j]) && num[j] != '.') //check that it is a number and not a letter or symbol
            {
                return "invalid input";
            }

        }
        int count = 0;
        istringstream iss(distance);
        while (distance.find(' ') != string::npos) {
            int find = distance.find(' ');
            kStr = distance.substr(find + 1); //splits string into distance and k
            distance = distance.substr(0, find); //splits string into distance and k
            count++; //number of spaces in string
        }
        if (count != 1) {
            return false;
        }
        for (int i = 0; i < kStr.size(); i++) //checks that k is positive
        {
            if (!isdigit(kStr[i])) {
                return false;
            }
        }
        return true;
    }
}

bool Client::check_ip(const string& ip_address) {
    vector<std::string> octets;
    // Split the IP address into octets
    string octet;
    for (char c : ip_address) {
        if (c == '.') {
            octets.push_back(octet);
            octet.clear();
        } else {
            octet += c;
        }
    }
    octets.push_back(octet);

    // Check that there are exactly four octets
    if (octets.size() != 4) {
        return false;
    }

    // Check that all octets are valid
    for (const string& octet : octets) {
        // Check that the octet is not empty
        if (octet.empty()) {
            return false;
        }

        // Check that the octet contains only digits
        if (!all_of(octet.begin(), octet.end(), ::isdigit)) {
            return false;
        }

        // Check that the octet is in the range 0-255
        int octet_int = stoi(octet);
        if (octet_int < 0 || octet_int > 255) {
            return false;
        }
    }

    return true;
}

int main(int argc, char* argv[])
{
    if(argc != 3)
    {
        exit(1);
    }
    string port_str = argv[2];
    char *ip = argv[1];
    int port = stoi(port_str);
    if(port < 1024 or port > 65535) //checks port number
    {
        cout<< "port number is not valid";
        return 0;
    }
    Client cl = Client(ip, port);
    bool ip_flag = cl.check_ip(ip); //true if ip is valid, false otherwise
    if(!ip_flag)
    {
        cout<< "ip number is not valid"<<endl;
        return 0;
    }
    int rec = cl.CreateClient(ip, port);
}

# targil 3
### Instructions on how to run and compile exercise 3:
Run the following commands on the server:
1. git init
2. git clone -b targil3 https://github.com/lynnmolga/ap_2023.git
3. cd ap_2023 (in order to enter the folder of the repository)
4. make

<ins>In server terminal:</ins>

5. ./server.out + "Your arguments" (file and port number)
6. make clean (to clean all cache)

<ins>In client terminal:</ins>

5. ./server.out + "Your arguments" (IP number and port number)
6. Input "vector, distance and K value"
7. make clean (to clean all cache)

### Our code:
Our code has two main functions that communicate with each other via socket and port. 

The main function in the Server class recieves a file and port as arguments from the user and with this port binds to the client.

The main function in the Client class recieves an IP address and a port number as arguments from the user and binds through this port to the server. After the connection is established the client recieves a vector, type of distance and K from the user. The client checks if the given input it valid and sends it to the server, if it is not the client prints "invalid input".

The server then checks the input once again and if it is valid it returns the correct classification according to the given criteria. If the input is invalid the server will send an error message to the client which will then print it on the screen.

#### <ins>notes:</ins>

*If you wish to open one of the three files we have in our datasets folder please enter in the file path: /u/students/"Your username"/ap_2023/datasets/"dataset type"/"dataset"_classified.csv

*If the given input to the client is "-1" the client will then close the connection and the server will remain open.

*Our code accepts a vector of the same size as the vectors from the file, where the input is solely numeric and does not start or end with blankspaces.

*If the input vector is anything other than a series of numbers with blank spaces in between (e.g 1 2 3) such as letters or symbols the function will stop and send an error message, same as for k.

*In the case where the size of the vectors in the file are not the same the function will stop and send an error message.

*If the file is not found or cant be opened then you will recieve the message "Could not open the file" in the servers terminal and "invalid input" in the clients terminal.
